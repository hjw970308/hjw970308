/**
 * Project��	SC_CP.PRJ
 * Device:		FT61F021A/B
 * Author:		@CHEN
 * Version:		V1.6
 * Date:		2019.11.17
 * Description:	���������������ں㹦/���𶯵��Է���
*/
//===========================================================
#include	"SYSCFG.h";
#include	"stdlib.h"
//===========================================================
#define		_XTAL_FREQ		32000000								//2Tģʽ
#define		MODE_CP			1										//�㹦ģʽ
#define		MODE_SS			0										//������ģʽ
#define		enable			1
#define		disable			0
#define		turn_right		1
#define 	turn_left		0
#define		POT_Stepless	0			//�޼�����ģʽ
#define		POT_Gate		1			//�ֵ�����ģʽ

#define		PowerVoltage	230
#define 	ArrLength_OutVoltageRatio	200
volatile const unsigned int OutVoltageRatio[ArrLength_OutVoltageRatio + 1] = 
{
	0,
	451 ,638 ,782 ,903 ,1011,1109,1199,1282,1361,1436,
	1508,1576,1642,1705,1767,1826,1884,1940,1995,2049,
	2101,2153,2203,2252,2301,2349,2396,2442,2487,2532,
	2577,2620,2663,2706,2748,2790,2831,2872,2912,2952,
	2992,3031,3070,3109,3147,3185,3222,3260,3297,3333,
	3370,3407,3443,3479,3515,3550,3585,3621,3656,3691,
	3725,3760,3794,3827,3862,3896,3930,3963,3997,4031,
	4064,4097,4130,4163,4196,4229,4262,4294,4327,4360,
	4392,4424,4457,4489,4521,4553,4586,4618,4650,4682,
	4714,4746,4778,4809,4841,4873,4905,4937,4969,5000,
	5032,5064,5096,5128,5160,5192,5223,5255,5286,5319,
	5351,5383,5415,5447,5480,5512,5544,5577,5608,5641,
	5674,5707,5739,5772,5805,5838,5871,5904,5937,5970,
	6004,6037,6071,6105,6139,6173,6207,6241,6276,6310,
	6344,6380,6415,6451,6485,6522,6558,6594,6631,6667,
	6704,6741,6778,6816,6854,6892,6931,6969,7009,7049,
	7089,7129,7170,7211,7252,7295,7338,7381,7423,7469,
	7514,7559,7604,7652,7700,7749,7798,7848,7900,7952,
	8006,8061,8117,8175,8234,8296,8359,8425,8493,8565,
	8640,8719,8802,8892,8990,9097,9219,9363,9550,10000
};
#define 	RCConstantTime 						320		//���㴥�� RC ���ʱ�䣺510K + 510K + 220pF
//===========================================================
#define		Moto_mode							MODE_SS				//�������ģʽѡ��
#define		potentiometer_enable				enable				//��λ������ʹ��λ
#define		Potentiometer_Mode					POT_Stepless
//===========================================================
#define		GL									PC5
#define		TRI_IO1								PC0
#define		TRI_IO2								PC1
#define		TRI_IO3								PC4
#define		K3								    PA7
#define		K2									PA6
#define     SW                                  PA5
#define     QB                                  PC3
#define		cur_ad_channel						3					//����������ADͨ����
#if(potentiometer_enable	==	enable)
	#define		adjust_dir						turn_right			//��λ������
	#define		potentiometer_ad_channel		6					//��λ��������ADͨ����
#endif
#define		turn_on_time_min					1000				//�ɿع���С��ͨ��
#define		turn_on_time_max					(AC_signel_time/2-1000)	//�ɿع����ͨ��
#define		voltage_min							10					//��������ʼ��ѹֵ
#define		voltage_max							PowerVoltage - 10	//�������ܹ��򿪵�����ѹֵ
#define		voltage_base_min					60					//1����ѹֵ����͵���  ת���������ѹ
#define		voltage_base_frontmax				200					//5����ѹֵ����ߵ�ǰһ����
#define		voltage_base_max					220					//6����ѹֵ����ߵ���
#define		softstart_step_voltage				4					//��������С����
#define		SCR_ON								0					//���͵�ƽ�����ɿع�
#define		TRI_ON()							{TRI_IO1 = SCR_ON;TRI_IO2 = SCR_ON;TRI_IO3 = SCR_ON;}
#define		TRI_OFF()							{TRI_IO1 = !SCR_ON;TRI_IO2 = !SCR_ON;TRI_IO3 = !SCR_ON;}
#define		ADC_ON()							ADCON0 |=	0x02
//===========================================================
int 		AC_FREQ						=		50;
int			delay_on_timer				=		0;
int			delay_off_timer				=		0;
unsigned int load_current			    =		0;
char        cout1                       =       0;
char 		cout[2]						=		0;
int			AC_signel_time				=		0;					//���Ҳ�����
int			turn_on_time				=		0;
int			voltage_out					=		voltage_min;	
int			voltage_base				= 		voltage_base_min;	
unsigned char	AC_interrupt_cnt		=		0x00;
unsigned char	TIMER0_cnt				=		0;	
unsigned char 	T0IE_cnt				=		0;
unsigned char 	flag @ 0x20;
bit 		potentiometer_adjust_flag 	@ ((unsigned) & flag * 8) + 0;	//��λ����������
bit 		control_flag 				@ ((unsigned) & flag * 8) + 1;	//���㵼ͨ��
bit 		softstart_flag 				@ ((unsigned) & flag * 8) + 2;	//��������ɱ�־
bit 		AC_sine_ak 					@ ((unsigned) & flag * 8) + 3;	
bit 		GL_F 						@ ((unsigned) & flag * 8) + 4;	
bit			moto_on						@ ((unsigned) & flag * 8) + 5;	
bit			sw_flag						@ ((unsigned) & flag * 8) + 6;	
bit			tools_flag					@ ((unsigned) & flag * 8) + 7;	
unsigned char 	flag1 @ 0x21;
bit			water_flag					@ ((unsigned) & flag1 * 8) + 0;	
// bit			pump_flag					@ ((unsigned) & flag1 * 8) + 1;
bit			delay_on_flag				@ ((unsigned) & flag1 * 8) + 2;
bit			delay_off_flag				@ ((unsigned) & flag1 * 8) + 3;

unsigned char systick_20ms = 0;
unsigned char systick_20ms_last = 0;
unsigned char waterc_20ms = 0;
unsigned char waterc_20ms_last = 0;
unsigned char delayc_20ms = 0;
unsigned char delayc_20ms_last = 0;
//===========================================================

/* Delay */
void Delay_ms(unsigned char num)
{
	while(num --)
		__delay_ms(1);
}
void Delay_us(unsigned char num)
{
	while(num --)
		__delay_us(1);
}
/* ȡֵ�������涨ȡֵ���ֵ����Сֵ */
int num_range(int num,int num_min,int num_max)
{
	if(num_min > num_max)		return num_min;
	if(num < num_min)			return num_min;
	else if (num >= num_max)	return num_max;
        
	return num;
}
/* ����AD����ͨ�� */
void set_adc_chs(unsigned char CH)
{
	unsigned char x		=		CH;
	x					<<=		2;
	ADCON0				&=		0B11100011;
	ADCON0				|=		x;
}
/* ���Ź���ʼ�� */
void WDT_INIT(void)
{
	CLRWDT();
	WDTCON			=		0B00010001;	
}	
/* ADC��ʼ�� */
void ADC_INIT(void)		
{
	ADCON0		=		0B10000001;
	set_adc_chs(cur_ad_channel);
	#if(potentiometer_enable	==	1)
		ANSEL		|=		1 << potentiometer_ad_channel;
	#endif
	ANSEL		|=		1	<<	cur_ad_channel;
	ADCON1		=		0B01100000;
	ADIF		=		0;
}
/* ��ʱ����ʼ���������ɿع败������ʱ */
void TIMER0_INIT(void)
{
	T0CS		=		1;
	PSA			=		0;
	TMR0		=		0;
	T0IF		=		0;
	T0IE		=		1;
}
/* ��ʱ����ʼ�����������Ҳ����ڼ�ʱ */
void TIMER1_INIT(void)
{
	T1CON		=		0B00110011;
	TMR1L		=		0x00;
	TMR1H		=		0x00;
	TMR1IF		=		0;
	TMR1IE		=		1;
}
/* ȫ���ж�ʹ�� */
void ENABLE_INTERRUPT(void)
{
	GIE			=		1;
}
/* оƬ��ʼ�� */
void DEVICE_INIT(void)
{
	OSCCON			=		0B01110001;
	CMCON0			=		0B00000111;
	ANSEL			=		0B00000000;
	PORTA			=		0B00000000;
	TRISA			=		0B11111111;
	WPUA			=		0B00100000;
	PORTC			=		0B00010011;
	TRISC			=		0B11101100;
	WPUC			=		0B00011010;

	OPTION			=		0B00000010;

	ADC_INIT();
	TIMER0_INIT();
	TIMER1_INIT();
	ENABLE_INTERRUPT();
	WDT_INIT();
}
/* ����ɿع败��ʱ�� */
void fun_get_TriTime()
{
	unsigned int num_tmp;

	potentiometer_adjust_flag			=		1;
	control_flag		=		1;
	
	if(!moto_on) {control_flag = 0;control_flag = 1;turn_on_time = 0;softstart_flag = 0;voltage_out = voltage_min;}

	if(turn_on_time		!=		0)
	{
		num_tmp		=		(unsigned int)(AC_signel_time / 2)	-	(unsigned int)turn_on_time;
		TIMER0_cnt	=		num_tmp	>>	8;
		TMR0		=		255	-	(unsigned char)num_tmp; 
		T0CS		=		0;
		AC_sine_ak	=		1;
	}
}
/* ����turn_on_time */
int fun_get_TurnOnTime()
{
	long u32buf2;
	long u16buf1;
	u16buf1 = (long)voltage_out * ArrLength_OutVoltageRatio / PowerVoltage;
	u32buf2 = (OutVoltageRatio[u16buf1] + RCConstantTime);
	u32buf2 = u32buf2 * AC_signel_time / 20000;
	return u32buf2;
}
/* �ж���ں��� */
void interrupt ISR(void)
{
	/* ���Ҳ����ڶ�ʱ��� */
	if(TMR1IF	&&	TMR1IE)
	{
		TMR1IF		=		0;
		TMR1CS		=		1;
	}
	/* �ɿع趨ʱ���� */
	if(T0IE	&&	T0IF)
	{
		static char TRIMode = 0;	//TRIMode = 0:��ʱģʽ	TRIMode = 1:�ɿع败��ģʽ
		static char TRINum = 0;		//�ɿع�ʣ���败��������
		unsigned int num_tmp		=	0;

		if(T0IE_cnt <= 5) T0IE_cnt ++;

		if(TRIMode == 0)
		{
			if(TIMER0_cnt	>	0)		{TIMER0_cnt--;	T0IF = 0;return;}
			/* �ɿع败����ʽ������100uS������������ */
			T0CS = 1;
			if(T0IE_cnt > 0)	TRI_ON();
			TRIMode = 1;TRINum = 6;TMR0 = 220;
			T0CS = 0;

		}else
		{
			if(TRINum > 0) 
			{
				TRINum --;
				TRI_IO1 = !TRI_IO1;
				TRI_IO2 = !TRI_IO2;
				TRI_IO3 = !TRI_IO3;
				TMR0 = 220;
			}else
			{
				TRI_OFF();
				TRIMode = 0;
				T0CS = 1;
				if(AC_sine_ak	==	1)
				{
					num_tmp		=	(unsigned int)(AC_signel_time / 2 - 420);
					TIMER0_cnt	=	num_tmp >> 8;
					TMR0		=	255	-	(unsigned char)num_tmp; 
					T0CS		=	0;
					AC_sine_ak	=	0;
				}
			}
		}
		T0IF	=	0;
	}
	//===========================================================
}
void Button_check()
{
	static unsigned char cnt[3] = 0;
	if(systick_20ms != systick_20ms_last)
	{
		systick_20ms_last = systick_20ms;

		if(PA7 == 0 && PA6 == 1) 
		{
			cnt[1] ++;cnt[0] = 0;cnt[2] = 0;
			if(cnt[1] >= 5) {sw_flag = 0;cnt[1] = 100;}
		}
		else if(PA7 == 1 && PA6 == 0) 
		{
			cnt[2] ++;cnt[0] = 0;cnt[1] = 0;
			if(cnt[2] >= 5) {sw_flag = 1;cnt[2] = 100;}
		}else 
		{
			cnt[0] ++;cnt[1] = 0;cnt[2] = 0;
			if(cnt[0] >= 5) {sw_flag = 0;cnt[0] = 100;}
		}
	}

}

void Water_check()
{
	static unsigned char cnt1[2] = 0;
	if(waterc_20ms != waterc_20ms_last)
	{
		waterc_20ms_last = waterc_20ms;
		if(PC3 == 1 && PA5 == 1) 
		{	
			cnt1[0] ++;cnt1[1] = 0;
			if(cnt1[0] >= 5) {water_flag = 0;cnt1[0] = 100;}
		}
		else 
		{
			cnt1[1] ++;cnt1[0] = 0;
			if(cnt1[1] >= 5) {water_flag = 1;cnt1[1] = 100;}
		}	
	}
}

void Delay_Contral(void)
{
	if(water_flag == 0)
	{
		if(delayc_20ms != delayc_20ms_last)
		{
			delayc_20ms_last = delayc_20ms;
			if(delay_off_timer > 0)
			{
				delay_off_timer --;
				if(delay_off_timer == 0) moto_on = 0;
			}
			if(delay_on_timer > 0)
			{
				delay_on_timer --;
				if(delay_on_timer == 0) moto_on = 1;
			}
		}
	}else 
	{
		moto_on = 0;
	}

}


main()
{
	DEVICE_INIT();

	/* ��ʼADC��ѹ���� */
	{
		set_adc_chs(cur_ad_channel);
		Delay_us(20);
		ADC_ON();   		
	}
	moto_on = 0;

	while(1)
	{
		/* ι�� */
		Feed_Dog:{
			CLRWDT();
		}


		/* ��鿪��״̬ */
		Button_check();
		/*���ˮλ״̬*/
		Water_check();
		/* ��ʱ */
		Delay_Contral();
		

		/* �����źż�� */
        Check_GL_Sigal:{
			if(GL == 1 && GL_F == 0)
			{
				int AC_signel_time_buf = 0x0000;
				GL_F	=	1;
				TMR1CS = 1;
				AC_signel_time_buf		=		TMR1H;
				AC_signel_time_buf		*=		256;
				AC_signel_time_buf		+=		TMR1L;
									
				if(AC_signel_time_buf < 13333)
				{
					voltage_out = voltage_min;
					turn_on_time = turn_on_time_min;
					softstart_flag = 0;
					AC_interrupt_cnt = 0;
					TMR1CS = 0;goto Table2;
				}else if(AC_signel_time_buf > 25000)
				{
					TMR1H		=		0x00;	
					TMR1L		=		0x00;	
					TMR1CS		=		0;	goto Table2;
				}else				
				{
					TMR1H		=		0x00;	
					TMR1L		=		0x00;	
					TMR1CS		=		0;    
				}
				if(AC_interrupt_cnt < 5)
				{
					AC_interrupt_cnt += 1;
					if(AC_interrupt_cnt == 5)
					{
						if((AC_signel_time_buf > 15385) && (AC_signel_time_buf < 22222))
							AC_signel_time = AC_signel_time_buf;
						else
							AC_interrupt_cnt = 0;
					}
					goto Table2;
				}
				AC_signel_time += (AC_signel_time_buf	-	AC_signel_time)	/	16;
				if(AC_signel_time < 18333) AC_FREQ = 60;
				else AC_FREQ = 50;
				//=======================================================
				fun_get_TriTime();
				//=======================================================
			}
			if(GL == 0 && GL_F == 1)
			{
				GL_F = 0;
				systick_20ms ++;
				waterc_20ms ++;
				delayc_20ms ++;
			}
        }

		Table2:
		/* ADC���� */
		Check_ADC_Sigal:{
			if(ADIF		==		1)
			{
				int		TempADCBuffer	=	0x0000;
				static int		TempADCBuffer_last	=	0x0000;
				TempADCBuffer	=	ADRESH	&	0x03;
				TempADCBuffer	=	(TempADCBuffer	<<	8)	+	ADRESL;
				ADIF			=	0;
                /* ��ɵ�λ������������������� */
				#if(potentiometer_enable	==	1)
				if((ADCON0 & 0B00011100) == (potentiometer_ad_channel << 2))
				{
					#if(adjust_dir	==	1)
						TempADCBuffer	=	1023 - TempADCBuffer;
					#endif

					#if(Potentiometer_Mode == POT_Stepless)	//��λ���޼�����ģʽ
						#define		hysteresis_value	10
						if(TempADCBuffer < hysteresis_value) {TempADCBuffer = 0;TempADCBuffer_last = TempADCBuffer;voltage_base = voltage_base_min;}
						if(TempADCBuffer + hysteresis_value > 1023) {TempADCBuffer = 1023;TempADCBuffer_last = TempADCBuffer;voltage_base = voltage_base_max;}
						if(( (TempADCBuffer_last > hysteresis_value) && (TempADCBuffer < TempADCBuffer_last - hysteresis_value) )  || (TempADCBuffer > TempADCBuffer_last + hysteresis_value) )
						{
							TempADCBuffer_last = TempADCBuffer;
							voltage_base = (long)(voltage_base_frontmax - voltage_base_min) * TempADCBuffer_last / 1023 + voltage_base_min;
						}
					#endif

					set_adc_chs(cur_ad_channel);
					goto STOP_AD;
				}
				#else
					voltage_base	=	voltage_base_max;
				#endif
                /* ��ɵ������������������� */
				if(((ADCON0	& 0B00011100) == (cur_ad_channel << 2)))
				{
					cout1++;
					static unsigned int	buf	= 0;
					static unsigned int cnt = 0;
					if(cout1 > 100)
					{
						cout1 = 100;
						if(potentiometer_adjust_flag ==	0)
						{
							//if(TempADCBuffer >= 1)
							{
								buf += TempADCBuffer;
								cnt ++;
							}
						}
						else
						{
							if(cnt != 0)
							{
								load_current = buf / cnt;
							}else
							{
								load_current = 0;
							}
							cnt = 0;	
							buf = 0;


							if(sw_flag == 0)
							{
								if(load_current >= 12)
								{
									cout[0]++;
									cout[1] = 0;
									if(cout[0] >= 10)
									{
										if(delay_on_timer == 0)
										{
											delay_on_timer = AC_FREQ * 1 / 2;	//��ʱ1�뿪��
											delay_off_timer = 0;
										}
										cout[0] = 100;
									}
								}else 
								{
									cout[0] = 0;
									cout[1] ++;
									if(cout[1] >= 10)
									{
										if(delay_off_timer == 0)
										{
											delay_on_timer = 0;
											delay_off_timer = AC_FREQ * 7;	//��ʱ8��ػ�
										}

										cout[1] = 100;
									}
								}
							}else 
							{
								cout[0] = 0;cout[1] = 0;
								moto_on = 1;
								delay_on_timer = 0;
								delay_off_timer = 5;
							}
						}
						goto STOP_AD;
					}
				}

				STOP_AD:
				/* �����λ������ */
				if(potentiometer_adjust_flag ==	1)
				{
					#if(potentiometer_enable ==	enable)
						set_adc_chs(potentiometer_ad_channel);Delay_us(100);
					#endif
					potentiometer_adjust_flag = 0;
				}
				/* ����AD���� */
				ADC_ON();
				
			}
        }

		/* ����ɿع����� */
        Contral_TurnOnTime:{
			if(control_flag == 1)
			{
				control_flag = 0;
				static unsigned char scan_cnt = 0;
				int	tmp	;

				if(T0IE == 0)	{goto Contral_TurnOnTime;}

				if(softstart_flag	==	0)
				{
					//���������
					if(scan_cnt % 2 == 0)	tmp	= num_range(voltage_base,voltage_out - softstart_step_voltage,voltage_out + softstart_step_voltage);
					if(scan_cnt < 200)		scan_cnt ++;
					if((abs(voltage_out - voltage_base) < softstart_step_voltage) && (scan_cnt >= 100))	{scan_cnt = 0;softstart_flag = 1;}
				}else
				{
					scan_cnt = 0;
					//������������
					tmp = voltage_base;
				}
				voltage_out	= num_range(tmp ,voltage_min ,voltage_max);
				turn_on_time = fun_get_TurnOnTime();
				turn_on_time = num_range(turn_on_time,turn_on_time_min,turn_on_time_max);
			}
        }	
	}
}